vistarfmon - Enable and disable monitor mode on a NDIS 6 wireless adapter

Copyright (c) 2008, Joshua Wright <jwright@willhackforsushi.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License version 2 as
published by the Free Software Foundation. See COPYING for more
details.

vistarfmon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Public License version 2 for more details.

Portions of this code was adapted from the Windows Vista SDK for wireless
controls by Microsoft Corporation.


INTRODUCTION

This simple utility controls a NDIS 6 wireless adapter on Windows Vista to
enable or disable monitor mode.

C:\>vistarfmon.exe
vistarfmon: Enable and disable monitor mode on Vista NDIS 6 interfaces.
Copyright (c) 2008 Joshua Wright <jwright@willhackforsushi.com>

Usage: vistarfmon <interface number> <mon|sta>

Available interface(s):
  1. Intel(R) Wireless WiFi Link 4965AGN, Mode: ExSta, State: connected



Example:

C:\>vistarfmon 1 mon
Operation mode set to Monitor.



REQUIREMENTS

In order to use this tool, you'll need Windows Vista with a NDIS 6 native
WiFi driver.


VERSIONING

2008.12.8 - Initial release (1.0)



BUGS

None known at this time.


TODO

Suggestions welcome.


QUESTIONS/COMMENTS/SUGGESTIONS

Please contact jwright@willhackforsushi.com, thanks!

-Josh