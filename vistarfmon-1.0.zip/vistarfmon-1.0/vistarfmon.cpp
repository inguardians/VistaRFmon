/*
 * vistarfmon - Enable and disable monitor mode on a NDIS 6 wireless adapter
 *
 * Copyright (c) 2008, Joshua Wright <jwright@willhackforsushi.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation. See COPYING for more
 * details.
 *
 * vistarfmon is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Public License version 2 for more details.
 *
 * Some of this code was adapted from the Windows Vista SDK for wireless
 * controls by Microsoft Corporation.
 */

#define _WIN32_DCOM

#include <windows.h>
#include <conio.h>
#include <objbase.h>
#include <rpcsal.h>
#include <objbase.h>
#include <msxml6.h>
#include <atlbase.h>
#include <iostream>
#include <iomanip>
// headers needed to use WLAN APIs 
#include <wlanapi.h>

// get interface op mode string
LPWSTR getRadioOpModeString(ULONG wlanRadioOpMode) {
	LPWSTR strRetCode;

	switch(wlanRadioOpMode) {
		case DOT11_OPERATION_MODE_EXTENSIBLE_STATION:
			strRetCode = L"ExSta";
			break;
		case DOT11_OPERATION_MODE_NETWORK_MONITOR:
			strRetCode = L"Monitor";
			break;
		default:
			strRetCode = L"\"Unknown\"";
			break;
	}

	return strRetCode;
}

// get interface state string
LPWSTR getInterfaceStateString(WLAN_INTERFACE_STATE wlanInterfaceState) {
    LPWSTR strRetCode;

    switch(wlanInterfaceState) {
        case wlan_interface_state_not_ready:
            strRetCode = L"not ready";
            break;
        case wlan_interface_state_connected:
            strRetCode = L"connected";
            break;
        case wlan_interface_state_ad_hoc_network_formed:
            strRetCode = L"ad hoc network formed";
            break;
        case wlan_interface_state_disconnecting:
            strRetCode = L"disconnecting";
            break;
        case wlan_interface_state_disconnected:
            strRetCode = L"disconnected";
            break;
        case wlan_interface_state_associating:
            strRetCode = L"associating";
            break;
        case wlan_interface_state_discovering:
            strRetCode = L"discovering";
            break;
        case wlan_interface_state_authenticating:
            strRetCode = L"authenticating";
            break;
        default:
            strRetCode = L"invalid interface state";
    }

    return strRetCode;
}


// enumerate and display wireless interfaces
VOID printwlanint() {
    DWORD dwError = ERROR_SUCCESS;
    HANDLE hClient = NULL;
    PWLAN_INTERFACE_INFO_LIST pIntfList = NULL;
    RPC_WSTR strGuid = NULL;
	DWORD dwServiceVersion;
	DWORD dwDataSize;
	PVOID pData = NULL;
	DWORD wlanRadioOpMode;
    UINT i = 0;

    // open handle
	if ((dwError = WlanOpenHandle(WLAN_API_VERSION, NULL, &dwServiceVersion, &hClient)) != ERROR_SUCCESS) {
		fwprintf(stderr, L"Error opening interface enumeration handle: %d\n", dwError);
		return;
	}
		
	// enumerate wireless interfaces
	if ((dwError = WlanEnumInterfaces(hClient, NULL, &pIntfList)) != ERROR_SUCCESS) {
		fwprintf(stderr, L"Error enumerating wireless interfaces: %d\n", dwError);
		return;
	}

	wprintf(L"Available interface(s):\n");
	
	// print out interface information
	for (i = 0; i < pIntfList->dwNumberOfItems; i++) {
		if ((dwError = WlanQueryInterface(hClient, &pIntfList->InterfaceInfo[i].InterfaceGuid,
				wlan_intf_opcode_current_operation_mode, NULL, &dwDataSize, &pData, NULL)) 
				!= ERROR_SUCCESS && dwError != ERROR_NOT_SUPPORTED) {

			fwprintf(stderr, L"Error retrieving current operational mode: %d\n", dwError);
			return;
		}
		wlanRadioOpMode = *((ULONG *)pData);
		
		wprintf(L"  %d. %s, Mode: %s, State: %s\n", i+1, pIntfList->InterfaceInfo[i].strInterfaceDescription,
			getRadioOpModeString(wlanRadioOpMode),
			getInterfaceStateString(pIntfList->InterfaceInfo[i].isState));
	}

	if (pIntfList != NULL) {
		WlanFreeMemory(pIntfList);
	}

	if (hClient != NULL) {
		WlanCloseHandle(hClient, NULL);
	}

	return;
}

int _cdecl wmain(int argc, WCHAR* argv[]) {

	DWORD dwError = ERROR_SUCCESS;
	DWORD intNum = 0;
    HANDLE hClient = NULL;
    ULONG wlanRadioOpMode;
    PWLAN_INTERFACE_INFO_LIST pIntfList = NULL;
    RPC_WSTR strGuid = NULL;
	DWORD dwServiceVersion;
	DWORD dwDataSize;
	PVOID pData = NULL;
    UINT i = 0;


	if (argc != 3) {
		wprintf(L"vistarfmon: Enable and disable monitor mode on Vista NDIS 6 interfaces.\n");
		wprintf(L"Copyright (c) 2008 Joshua Wright <jwright@willhackforsushi.com>\n\n");
		wprintf(L"Usage: %s <interface number> <mon|sta>\n\n", argv[0]);
		printwlanint();
		return 1;
	}

	if (_wcsicmp(argv[2], L"mon") == 0)	{
		wlanRadioOpMode = DOT11_OPERATION_MODE_NETWORK_MONITOR;
	} else if (_wcsicmp(argv[2], L"sta") == 0) {
		wlanRadioOpMode = DOT11_OPERATION_MODE_EXTENSIBLE_STATION;
	} else {
		fwprintf(stderr, L"Invalid opmode specified: \"%s\".  Must be \"mon\" or \"sta\".\n", argv[2]);
		return -1;
	}

	intNum = _wtoi(argv[1]);

	// open handle
	if ((dwError = WlanOpenHandle(WLAN_API_VERSION, NULL, &dwServiceVersion, &hClient)) != ERROR_SUCCESS) {
		fwprintf(stderr, L"Error opening WLAN handle: %d\n", dwError);
		return -1;
	}

	// enumerate wireless interfaces
	if ((dwError = WlanEnumInterfaces(hClient, NULL, &pIntfList)) != ERROR_SUCCESS) {
		fwprintf(stderr, L"Error enumerating WLAN interfaces: %d\n", dwError);
		return -1;
	}

	if (intNum > (pIntfList->dwNumberOfItems+1)) {
		fwprintf(stderr, L"Invalid interface number specified: %d.\n", intNum);
		return -1;
	}

	/* Decrement to match array index of interfaces */
	intNum--;

	if ((dwError = WlanSetInterface(hClient, &pIntfList->InterfaceInfo[intNum].InterfaceGuid, 
		wlan_intf_opcode_current_operation_mode, sizeof(ULONG),	(PVOID)&wlanRadioOpMode,
		NULL)) != ERROR_SUCCESS) {
			fwprintf(stderr, L"Error setting WLAN interface operational mode: %d\n", dwError);
			return -1;
	}

	Sleep(1000);

	/* Check mode following set */
	if ((dwError = WlanQueryInterface(hClient, &pIntfList->InterfaceInfo[intNum].InterfaceGuid,
			wlan_intf_opcode_current_operation_mode, NULL, &dwDataSize, &pData, NULL)) 
			!= ERROR_SUCCESS && dwError != ERROR_NOT_SUPPORTED) {
		fwprintf(stderr, L"Error retrieving current operational mode: %d\n", dwError);
		return -1;
	}

	if (dwError == ERROR_SUCCESS) {
		if (dwDataSize != sizeof(ULONG)) {
			fwprintf(stderr, L"Error retrieving current operational mode: %d\n", dwError);
			return -1;
		}

		wlanRadioOpMode = *((ULONG *)pData);
		wprintf(L"Operation mode set to %s.\n", getRadioOpModeString(wlanRadioOpMode));

		WlanFreeMemory(pData);
		pData = NULL;
	} else {
		fwprintf(stderr, L"Error retrieving current operational mode: %d\n", dwError);
		return -1;
	}


	if (pIntfList != NULL) {
		WlanFreeMemory(pIntfList);
	}

	if (hClient != NULL) {
		WlanCloseHandle(hClient, NULL);
	}
	
	return 0;
}
